<?php

header('Content-Type: application/json; charset=utf-8');

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method.'
    ]);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

$userMessage = trim($input['message'] ?? '');

if ($userMessage === '') {
    echo json_encode([
        'success' => false,
        'message' => 'Message is empty.'
    ]);
    exit;
}

$url = 'https://api.groq.com/openai/v1/chat/completions';

$data = [
    'model' => 'llama-3.3-70b-versatile',

    'messages' => [
        [
            'role' => 'system',
            'content' => 'You are Femora AI, a helpful women health information assistant. Give general educational information and encourage professional medical care when appropriate.'
        ],
        [
            'role' => 'user',
            'content' => $userMessage
        ]
    ],

    'temperature' => 0.4,
    'max_tokens' => 500
];

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . GROQ_API_KEY
]);

curl_setopt($ch, CURLOPT_TIMEOUT, 30);

$response = curl_exec($ch);

$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);

curl_close($ch);


if ($curlError) {

    echo json_encode([
        'success' => false,
        'message' => 'cURL Error: ' . $curlError
    ]);

    exit;
}


$result = json_decode($response, true);


if ($httpCode < 200 || $httpCode >= 300) {

    echo json_encode([
        'success' => false,
        'message' => 'Groq API Error (' . $httpCode . '): ' .
            ($result['error']['message'] ?? $response)
    ]);

    exit;
}


$reply = $result['choices'][0]['message']['content'] ?? '';


if ($reply === '') {

    echo json_encode([
        'success' => false,
        'message' => 'Groq returned an empty response.'
    ]);

    exit;
}


echo json_encode([
    'success' => true,
    'reply' => $reply
], JSON_UNESCAPED_UNICODE);

?>