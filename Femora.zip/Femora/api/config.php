<?php

define('GROQ_API_KEY','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');

?>